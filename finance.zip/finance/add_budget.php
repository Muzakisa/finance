<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $category = $_POST['category'];
    $amount = $_POST['amount'];

    // Insert the budget into the database
    $query = "INSERT INTO budget (user_id, category, amount) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("isd", $user_id, $category, $amount);
    if ($stmt->execute()) {
        header("Location: view_budget.php"); // Redirect to view budget page after success
    } else {
        $error_message = "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Budget</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Add New Budget</h2>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <form method="POST" action="add_budget.php">
            <div class="mb-3">
                <label for="category" class="form-label">Category</label>
                <input type="text" class="form-control" name="category" required placeholder="Enter Category">
            </div>
            <div class="mb-3">
                <label for="amount" class="form-label">Amount (UGX)</label>
                <input type="number" class="form-control" name="amount" required placeholder="Enter Amount" min="0">
            </div>
            <button type="submit" class="btn btn-primary w-100">Add Budget</button>
        </form>

        <div class="mt-3 text-center">
            <a href="view_budget.php" class="btn btn-secondary">Back to Budget Overview</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
