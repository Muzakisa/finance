<?php
session_start();
include('db.php');
require_once('tcpdf/tcpdf.php');  // Correct the path to the tcpdf.php file

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch expenses for the user
$query = "SELECT category, amount, description, date FROM expenses WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Create a new PDF document
$pdf = new TCPDF();
$pdf->AddPage();

// Set title
$pdf->SetFont('helvetica', 'B', 14);
$pdf->Cell(0, 10, 'Expense Report', 0, 1, 'C');

// Set table headers
$pdf->SetFont('helvetica', '', 12);
$pdf->Cell(50, 10, 'Category', 1);
$pdf->Cell(40, 10, 'Amount (UGX)', 1);
$pdf->Cell(70, 10, 'Description', 1);
$pdf->Cell(30, 10, 'Date', 1);
$pdf->Ln();

// Add table data (expenses)
$pdf->SetFont('helvetica', '', 10);
while ($row = $result->fetch_assoc()) {
    $pdf->Cell(50, 10, $row['category'], 1);
    $pdf->Cell(40, 10, number_format($row['amount'], 0), 1);
    $pdf->Cell(70, 10, $row['description'], 1);
    $pdf->Cell(30, 10, $row['date'], 1);
    $pdf->Ln();
}

// Output the PDF
$pdf->Output('expenses_report.pdf', 'D');
exit;
?>
