<?php
// Database connection settings
$servername = "localhost";  // Usually localhost
$username = "root";         // Your database username
$password = "";             // Your database password
$dbname = "financial";    // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
