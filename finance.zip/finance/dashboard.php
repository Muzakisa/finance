<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Include database connection
include('db.php');

// Fetch user details
$user_id = $_SESSION['user_id'];
$stmt_user = $conn->prepare("SELECT username FROM users WHERE id = ?");
$stmt_user->bind_param("i", $user_id);
$stmt_user->execute();
$result_user = $stmt_user->get_result();
$user = $result_user->fetch_assoc();
$username = $user['username'];

// Fetch total balance
$balanceQuery = "SELECT SUM(amount) AS total_balance FROM budget WHERE user_id = ?";
$stmt_balance = $conn->prepare($balanceQuery);
$stmt_balance->bind_param("i", $user_id);
$stmt_balance->execute();
$totalBalance = $stmt_balance->get_result()->fetch_assoc()['total_balance'] ?? 0;

// Fetch total expenses
$expenseQuery = "SELECT SUM(amount) AS total_expenses FROM expenses WHERE user_id = ?";
$stmt_expense = $conn->prepare($expenseQuery);
$stmt_expense->bind_param("i", $user_id);
$stmt_expense->execute();
$totalExpenses = $stmt_expense->get_result()->fetch_assoc()['total_expenses'] ?? 0;

// Calculate total income (Assume it's balance minus expenses for now)
$totalIncome = $totalBalance + $totalExpenses;

// Prepare data for the charts
$expenseBreakdownQuery = "
    SELECT category, SUM(amount) AS total 
    FROM expenses 
    WHERE user_id = ? 
    GROUP BY category
";
$stmt_expense_breakdown = $conn->prepare($expenseBreakdownQuery);
$stmt_expense_breakdown->bind_param("i", $user_id);
$stmt_expense_breakdown->execute();
$expenseBreakdownData = $stmt_expense_breakdown->get_result()->fetch_all(MYSQLI_ASSOC);

$monthlyTrendQuery = "
    SELECT MONTHNAME(date) AS month, SUM(amount) AS total 
    FROM expenses 
    WHERE user_id = ? 
    GROUP BY MONTH(date) 
    ORDER BY MONTH(date)
";
$stmt_monthly_trend = $conn->prepare($monthlyTrendQuery);
$stmt_monthly_trend->bind_param("i", $user_id);
$stmt_monthly_trend->execute();
$monthlyTrendData = $stmt_monthly_trend->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-light">

<!-- Header -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary px-4">
    <a class="navbar-brand" href="#">FinanceApp</a>
    <div class="ms-auto">
        <a href="view_expenses.php" class="btn btn-outline-light btn-sm">Expenses</a>
        <a href="view_budget.php" class="btn btn-outline-light btn-sm">Budgets</a>
        <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
    </div>
</nav>

<div class="container mt-4">
    <!-- Welcome Section -->
    <div class="text-center mb-4">
        <h2>Welcome, <?php echo htmlspecialchars($username); ?>!</h2>
        <p class="text-muted">Here's a snapshot of your finances</p>
    </div>

    <!-- Financial Overview -->
    <div class="row text-center">
        <div class="col-md-4">
            <div class="card shadow-sm p-3 mb-4">
                <h5 class="card-title">Total Balance</h5>
                <h3 class="text-success">UGX <?php echo number_format($totalBalance, 0); ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm p-3 mb-4">
                <h5 class="card-title">Total Income</h5>
                <h3 class="text-primary">UGX <?php echo number_format($totalIncome, 0); ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm p-3 mb-4">
                <h5 class="card-title">Total Expenses</h5>
                <h3 class="text-danger">UGX <?php echo number_format($totalExpenses, 0); ?></h3>
            </div>
        </div>
    </div>

    <!-- Charts Section -->
    <div class="row">
        <!-- Expense Breakdown -->
        <div class="col-md-6">
            <div class="card p-4 shadow-sm">
                <h5>Expense Breakdown</h5>
                <canvas id="expenseChart"></canvas>
            </div>
        </div>

        <!-- Monthly Spending Trend -->
        <div class="col-md-6">
            <div class="card p-4 shadow-sm">
                <h5>Monthly Spending Trend</h5>
                <canvas id="spendingTrend"></canvas>
            </div>
        </div>
    </div>

    <!-- Budget Progress -->
    <div class="mt-4">
        <h5>Budget Progress</h5>
        <div class="card p-4 shadow-sm">
            <!-- Example budget progress -->
            <div class="mb-2">
                <small>Food</small>
                <div class="progress">
                    <div class="progress-bar bg-success" style="width: 75%;">75%</div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="bg-primary text-white text-center py-3 mt-4">
       <p>&copy; 2024 FinanceApp</p>
</footer>

<script>
    // Expense Breakdown Chart
    const expenseCtx = document.getElementById('expenseChart').getContext('2d');
    const expenseData = {
        labels: <?php echo json_encode(array_column($expenseBreakdownData, 'category')); ?>,
        datasets: [{
            data: <?php echo json_encode(array_column($expenseBreakdownData, 'total')); ?>,
            backgroundColor: ['#4CAF50', '#FFC107', '#2196F3', '#F44336'],
        }]
    };
    new Chart(expenseCtx, {
        type: 'pie',
        data: expenseData
    });

    // Monthly Spending Trend Chart
    const trendCtx = document.getElementById('spendingTrend').getContext('2d');
    const trendData = {
        labels: <?php echo json_encode(array_column($monthlyTrendData, 'month')); ?>,
        datasets: [{
            label: 'Spending (UGX)',
            data: <?php echo json_encode(array_column($monthlyTrendData, 'total')); ?>,
            borderColor: '#4CAF50',
            fill: false,
            tension: 0.3
        }]
    };
    new Chart(trendCtx, {
        type: 'line',
        data: trendData
    });
</script>
</body>
</html>
