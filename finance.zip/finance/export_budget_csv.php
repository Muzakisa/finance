<?php
session_start();
include('db.php');

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch budget for the user
$query = "SELECT category, budget_limit, amount_spent, (budget_limit - amount_spent) AS remaining FROM budget WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Prepare CSV headers
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="budget.csv"');

// Open output stream
$output = fopen('php://output', 'w');

// Write column headers
fputcsv($output, ['Category', 'Budget Limit (UGX)', 'Amount Spent (UGX)', 'Remaining (UGX)']);

// Write data rows
while ($row = $result->fetch_assoc()) {
    fputcsv($output, [
        $row['category'],
        number_format($row['budget_limit'], 0),
        number_format($row['amount_spent'], 0),
        number_format($row['remaining'], 0)
    ]);
}

// Close the output stream
fclose($output);
exit;
?>
